
This is a low-polygon PBR model of abandoned water tower
Available in three different formats.
Blender .blend ,  FBX and OBJ.

Software used: Blender 2.83 & Substance Painter

Texture Maps: Base Color, Metallic, Normal and Roughness

UV Mapped - Yes 
Overlapping UVs - Yes

Faces Count  : 1427
Vertex Count  : 1906

Renderer   : Blender Eevee

..........................

Can be used commercially with credits.
Content not for redistribution.

www.animatedheaven.weebly.com
